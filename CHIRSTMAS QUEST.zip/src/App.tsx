import { useEffect, useState } from "react"

type Page = "home" | "characters" | "treasures" | "character-detail" | "game"

interface NavigationProps {
  page: Page
  goTo: (page: Page) => void
}

type CatalogEntry = {
  id: string
  name: string
  subtitle: string
  description: string
  color: string
  symbol: string
  tag: string
  image?: string
  scripture?: string
}

type CharacterEntry = CatalogEntry & {
  image: string
  verse: string
  quote: string
  story: string[]
  traits: string[]
  famousEvent: string
  books: string
}

const characterEntries: CharacterEntry[] = [
  {
    id: "jesus",
    name: "耶穌基督",
    subtitle: "THE SAVIOR",
    description: "道成肉身的救主，以愛、真理與復活帶來永恆盼望。",
    color: "#a64c3d",
    symbol: "✦",
    tag: "救恩",
    image: "/characters/01-jesus.webp",
    verse: "約翰福音 14:6",
    quote:
      "耶穌說：我就是道路、真理、生命；若不藉著我，沒有人能到父那裡去。",
    famousEvent: "十字架與復活",
    books: "未親筆撰寫聖經書卷；其生平與教導記載於四福音書",
    story: [
      "耶穌在伯利恆降生，走遍各城各鄉宣講天國、醫治病人、使瞎眼得看見，也以比喻向人顯明上帝的心意。",
      "祂為世人的罪被釘十字架，第三日從死裡復活。這是基督信仰的核心：死亡不是終點，愛與生命已經得勝。",
    ],
    traits: ["救主", "真光", "復活生命"],
  },
  {
    id: "evangelist",
    name: "無名傳道者",
    subtitle: "THE MESSENGER",
    description: "代表每一位領受使命、把福音帶到世界各處的基督徒。",
    color: "#3c70a4",
    symbol: "◆",
    tag: "使命",
    image: "/characters/02-evangelist.webp",
    verse: "馬太福音 28:19",
    quote:
      "所以，你們要去，使萬民作我的門徒，奉父、子、聖靈的名給他們施洗。",
    famousEvent: "承接大使命，勇敢傳揚福音",
    books: "代表歷世歷代所有基督徒，並非單一聖經作者",
    story: [
      "這張卡牌不是指某一位有名字的人，而是代表每一位回應耶穌大使命的基督徒。他們在家庭、校園、職場與遠方，以生命和言語分享福音。",
      "傳道者不一定站在講台上；每一位願意把盼望帶給身邊之人的門徒，都在延續使徒行傳尚未結束的故事。",
    ],
    traits: ["勇敢出發", "忠心見證", "分享福音"],
  },
  {
    id: "andrew",
    name: "安德烈",
    subtitle: "THE INVITER",
    description: "總是把人帶到耶穌面前，也把微小的奉獻交在主手中。",
    color: "#4b72a2",
    symbol: "◇",
    tag: "引路",
    image: "/characters/03-andrew.webp",
    verse: "約翰福音 1:41",
    quote:
      "他先找著自己的哥哥西門，對他說：我們遇見彌賽亞了。（彌賽亞翻出來就是基督。）",
    famousEvent: "帶來五餅二魚的孩子",
    books: "聖經未記載安德烈撰寫任何書卷",
    story: [
      "安德烈是最早跟隨耶穌的門徒之一。他先找到哥哥西門彼得，告訴他「我們遇見彌賽亞了」，並親自領他去見耶穌。",
      "五千人需要食物時，也是安德烈注意到一個帶著五個餅、兩條魚的孩子。他把看似微小的資源帶到耶穌面前，見證了餵飽眾人的神蹟。",
    ],
    traits: ["主動邀請", "看見微小", "帶人見主"],
  },
  {
    id: "peter",
    name: "彼得",
    subtitle: "THE ROCK",
    description: "從衝動的漁夫成為初代教會領袖，在恩典中重新站立。",
    color: "#3b668c",
    symbol: "▲",
    tag: "磐石",
    image: "/characters/04-peter.webp",
    verse: "馬太福音 16:16",
    quote: "西門彼得回答說：你是基督，是永生神的兒子。",
    famousEvent: "在海面上行走",
    books: "彼得前書、彼得後書",
    story: [
      "彼得看見耶穌在海面上行走，便求主讓他也走到水面上。當他定睛耶穌時真的走了起來，後來因看見風浪而害怕下沉，耶穌立刻伸手拉住他。",
      "他曾三次不認主，復活的耶穌卻三次問他「你愛我嗎」，重新託付他牧養群羊。五旬節後，彼得勇敢講道，成為初代教會的重要領袖。",
    ],
    traits: ["勇敢跨出", "真實悔改", "牧養群羊"],
  },
  {
    id: "john",
    name: "約翰",
    subtitle: "THE BELOVED",
    description: "被稱為主所愛的門徒，以真理與愛見證永恆生命。",
    color: "#70518e",
    symbol: "✧",
    tag: "愛",
    image: "/characters/05-john.webp",
    verse: "約翰一書 4:19",
    quote: "我們愛，因為神先愛我們。",
    famousEvent: "拔摩海島看見末世異象",
    books: "約翰福音、約翰一書、二書、三書、啟示錄",
    story: [
      "約翰與哥哥雅各一同蒙召，從性情剛烈的「雷子」成為最深刻書寫愛的使徒。他親眼見證耶穌登山變像，也在十字架下接受照顧馬利亞的託付。",
      "晚年被放逐到拔摩海島時，他看見關於基督得勝與新天新地的異象，寫成啟示錄，鼓勵受苦的教會持守盼望。",
    ],
    traits: ["住在愛中", "忠心見證", "看見異象"],
  },
  {
    id: "elisha",
    name: "以利沙",
    subtitle: "THE HEIR",
    description: "承接先知的外衣，以加倍的靈服事百姓、彰顯憐憫。",
    color: "#8f7044",
    symbol: "≈",
    tag: "承接",
    image: "/characters/06-elisha.webp",
    verse: "列王紀下 2:9",
    quote:
      "過去之後，以利亞對以利沙說：我未曾被接去離開你，你要我為你做什麼，只管求我。以利沙說：願感動你的靈加倍地感動我。",
    famousEvent: "承接以利亞的外衣與加倍恩膏",
    books: "聖經未記載以利沙撰寫任何書卷",
    story: [
      "以利亞乘旋風升天時，外衣掉落在以利沙面前。以利沙拾起外衣，擊打約旦河，河水隨即分開，印證先知職分的承接。",
      "他的服事充滿憐憫：使寡婦的油不斷、使書念婦人的兒子復活，也指示乃縵在約旦河沐浴而得醫治。",
    ],
    traits: ["忠心跟隨", "承接使命", "憐憫服事"],
  },
  {
    id: "david",
    name: "大衛",
    subtitle: "THE SHEPHERD KING",
    description: "從牧羊少年成為君王，以信心迎戰巨人，也以詩歌敬拜。",
    color: "#a45b35",
    symbol: "●",
    tag: "勇氣",
    image: "/characters/07-david.webp",
    verse: "撒母耳記上 17:45",
    quote:
      "大衛對非利士人說：你來攻擊我，是靠著刀槍和銅戟；我來攻擊你，是靠著萬軍之耶和華的名，就是你所怒罵帶領以色列軍隊的神。",
    famousEvent: "以機弦甩石擊敗歌利亞",
    books: "傳統認為大衛寫下許多詩篇，詩篇中有 73 篇標明與大衛相關",
    story: [
      "當以色列軍隊害怕巨人歌利亞時，年輕的大衛相信爭戰的勝敗在乎上帝。他只帶著牧羊人的杖、機弦和五顆光滑石子迎戰。",
      "一顆石子擊中歌利亞額頭，巨人倒下。大衛日後成為以色列王，也在成功與失敗中學習悔改，留下許多真誠的敬拜詩歌。",
    ],
    traits: ["信心迎戰", "熱情敬拜", "願意悔改"],
  },
  {
    id: "joseph",
    name: "約瑟",
    subtitle: "THE DREAMER",
    description: "在背叛與牢獄中仍持守信心，最終成為拯救家族的器皿。",
    color: "#a46b3f",
    symbol: "✺",
    tag: "饒恕",
    image: "/characters/08-joseph.webp",
    verse: "創世記 50:20",
    quote:
      "從前你們的意思是要害我，但神的意思原是好的，要保全許多人的性命，成就今日的光景。",
    famousEvent: "解夢並預備七年荒年",
    books: "聖經未記載約瑟撰寫任何書卷",
    story: [
      "約瑟被兄長出賣到埃及，又因誣告下在監裡；但上帝與他同在，使他能解開法老關於七個豐年與七個荒年的夢。",
      "約瑟被立為埃及宰相，預先儲備糧食，在饑荒中救了許多人的性命。面對曾傷害他的兄長，他選擇饒恕，看見上帝能使苦難轉為祝福。",
    ],
    traits: ["持守純正", "忠心管理", "選擇饒恕"],
  },
  {
    id: "daniel",
    name: "但以理",
    subtitle: "THE FAITHFUL EXILE",
    description: "身處異國權力中心仍堅持禱告，在獅子坑中經歷保守。",
    color: "#6d5b83",
    symbol: "◇",
    tag: "忠心",
    image: "/characters/09-daniel.webp",
    verse: "但以理書 6:23",
    quote:
      "王就甚喜樂，吩咐人將但以理從坑裡繫上來。於是但以理從坑裡被繫上來，身上毫無傷損，因為信靠他的神。",
    famousEvent: "獅子坑中蒙天使保護",
    books: "但以理書（傳統歸於但以理）",
    story: [
      "但以理被擄到巴比倫後，仍持守信仰與禱告生活。即使王下令禁止向任何神祈求，他仍像往常一樣每日三次向上帝禱告。",
      "他因此被丟入獅子坑，上帝卻差遣天使封住獅子的口。翌日但以理平安出坑，王也宣告眾人當敬畏永生的上帝。",
    ],
    traits: ["堅持禱告", "不向環境低頭", "信靠到底"],
  },
  {
    id: "elijah",
    name: "以利亞",
    subtitle: "THE FIRE PROPHET",
    description: "在悖逆世代勇敢發聲，也在微小聲音中重新得力。",
    color: "#8b4935",
    symbol: "▲",
    tag: "烈火",
    image: "/characters/10-elijah.webp",
    verse: "列王紀上 18:37",
    quote:
      "耶和華啊，求你應允我，應允我！使這民知道你－耶和華是神，又知道是你叫這民的心回轉。",
    famousEvent: "迦密山降火，顯明真神",
    books: "聖經未記載以利亞撰寫任何書卷",
    story: [
      "在迦密山上，以利亞獨自面對巴力先知。他築壇、澆水並向上帝禱告，天上立刻降下火來，燒盡祭物、木柴、石頭和溝裡的水。",
      "神蹟之後，以利亞也曾疲倦逃跑。上帝在曠野供應他，又以微小的聲音安慰並重新差遣他，顯明剛強的僕人同樣需要休息與恩典。",
    ],
    traits: ["勇敢發聲", "火熱禱告", "重新得力"],
  },
  {
    id: "moses",
    name: "摩西",
    subtitle: "THE DELIVERER",
    description: "帶領以色列人離開埃及，在曠野中領受律法與上帝同行。",
    color: "#527c9a",
    symbol: "≋",
    tag: "帶領",
    image: "/characters/11-moses.webp",
    verse: "出埃及記 14:13",
    quote:
      "摩西對百姓說：不要懼怕，只管站住！看耶和華今天向你們所要施行的救恩。因為，你們今天所看見的埃及人必永遠不再看見了。",
    famousEvent: "分開紅海，帶領百姓出埃及",
    books: "傳統認為摩西撰寫摩西五經：創世記、出埃及記、利未記、民數記、申命記",
    story: [
      "摩西在荊棘火焰中蒙上帝呼召，回到埃及面對法老，帶領受奴役的以色列人離開。當百姓被追兵逼到紅海邊時，上帝使海水分開，為他們開出道路。",
      "在西奈山上，摩西領受十誡與律法。他在曠野四十年陪伴百姓，即使面對抱怨與困難，仍一次次為他們代求，學習以謙和忠心承擔使命。",
    ],
    traits: ["勇敢帶領", "忠心代求", "領受律法"],
  },
  {
    id: "jacob",
    name: "雅各",
    subtitle: "THE WRESTLER",
    description: "從抓住祝福的人，成為與上帝摔跤後生命被更新的以色列。",
    color: "#756194",
    symbol: "◇",
    tag: "更新",
    image: "/characters/12-jacob.webp",
    verse: "創世記 32:28",
    quote:
      "那人說：你的名不要再叫雅各，要叫以色列；因為你與神與人較力，都得了勝。",
    famousEvent: "毗努伊勒與上帝摔跤",
    books: "聖經未記載雅各撰寫任何書卷",
    story: [
      "雅各曾用自己的方法抓住長子的名分與祝福，也因此離家多年。上帝卻在伯特利的夢中向他顯現，以通天的梯子應許與他同在並帶他回家。",
      "回鄉前夕，雅各整夜與一位神祕人物摔跤。天亮時他得著祝福，也得了新名字「以色列」。從此他帶著瘸腿前行，記得真正的祝福來自上帝。",
    ],
    traits: ["渴慕祝福", "生命更新", "緊緊抓住"],
  },
  {
    id: "abraham",
    name: "亞伯拉罕",
    subtitle: "THE FATHER OF FAITH",
    description: "因信離開故鄉，跟隨上帝走向未見之地，成為信心之父。",
    color: "#6a789b",
    symbol: "✦",
    tag: "信心",
    image: "/characters/13-abraham.webp",
    verse: "創世記 15:6",
    quote: "亞伯蘭信耶和華，耶和華就以此為他的義。",
    famousEvent: "仰望繁星，領受後裔之約",
    books: "聖經未記載亞伯拉罕撰寫任何書卷",
    story: [
      "上帝呼召亞伯拉罕離開本地、本族、父家，前往祂所指示的地方。雖然不知道終點在哪裡，他仍憑信心出發，在旅途中築壇敬拜。",
      "當亞伯拉罕年老仍沒有兒子時，上帝帶他觀看滿天星辰，應許他的後裔也要如此眾多。他相信上帝的話，後來在年老時迎來應許之子以撒。",
    ],
    traits: ["憑信出發", "等候應許", "築壇敬拜"],
  },
  {
    id: "noah",
    name: "諾亞",
    subtitle: "THE ARK BUILDER",
    description: "在世代敗壞時仍與上帝同行，憑信心建造方舟保存生命。",
    color: "#4f887f",
    symbol: "⌒",
    tag: "順服",
    image: "/characters/14-noah.webp",
    verse: "創世記 6:22",
    quote: "挪亞就這樣行。凡神所吩咐的，他都照樣行了。",
    famousEvent: "建造方舟，迎接彩虹之約",
    books: "聖經未記載諾亞撰寫任何書卷",
    story: [
      "在人們遠離上帝的世代，諾亞仍選擇與上帝同行。當他領受建造方舟的命令時，即使洪水尚未來到，仍照著上帝的吩咐預備一切。",
      "洪水退去後，諾亞一家與各樣活物離開方舟。他築壇感恩，上帝以彩虹作為立約的記號，應許保存大地與生命。",
    ],
    traits: ["全然順服", "持守正直", "保全生命"],
  },
  {
    id: "solomon",
    name: "所羅門",
    subtitle: "THE WISE KING",
    description: "向上帝求智慧治理百姓，並建造聖殿，使敬拜有榮耀居所。",
    color: "#80558b",
    symbol: "◆",
    tag: "智慧",
    image: "/characters/15-solomon.webp",
    verse: "列王紀上 3:9",
    quote:
      "所以求你賜我智慧，可以判斷你的民，能辨別是非。不然，誰能判斷這眾多的民呢？",
    famousEvent: "求智慧並建造耶路撒冷聖殿",
    books: "傳統認為所羅門與箴言、傳道書、雅歌等智慧文學密切相關",
    story: [
      "所羅門登基後，上帝在夢中問他想求什麼。他沒有求長壽或財富，而是求一顆能分辨是非的智慧之心，好好治理百姓；這個祈求蒙上帝喜悅。",
      "他召集工匠建造耶路撒冷聖殿，完成父親大衛的心願。聖殿奉獻時，所羅門帶領百姓禱告，承認天地尚且容不下上帝，祈求祂垂聽每一位尋求者。",
    ],
    traits: ["尋求智慧", "公義判斷", "建造聖殿"],
  },
]

const biblicalCharacterOrder = [
  "jesus",
  "noah",
  "abraham",
  "jacob",
  "joseph",
  "moses",
  "david",
  "solomon",
  "elijah",
  "elisha",
  "daniel",
  "peter",
  "andrew",
  "john",
  "evangelist",
]

const characters = biblicalCharacterOrder.map(
  (id) => characterEntries.find((character) => character.id === id)!,
)

const treasures: CatalogEntry[] = [
  {
    id: "salvation-helmet",
    name: "救恩的頭盔",
    subtitle: "HELMET OF SALVATION",
    description: "戴上救恩的頭盔，讓得救的盼望保守心思，不被謊言動搖。",
    color: "#8f493b",
    symbol: "✦",
    tag: "屬靈軍裝",
    image: "/treasures/helmet.png",
    scripture: "以弗所書 6:17",
  },
  {
    id: "righteousness-breastplate",
    name: "公義的護心鏡",
    subtitle: "BREASTPLATE OF RIGHTEOUSNESS",
    description: "以公義遮護內心，在每個選擇中持守正直，勇敢站立。",
    color: "#8b5b3e",
    symbol: "◆",
    tag: "屬靈軍裝",
    image: "/treasures/breastplate.png",
    scripture: "以弗所書 6:14",
  },
  {
    id: "truth-belt",
    name: "真理的帶子",
    subtitle: "BELT OF TRUTH",
    description: "用真理束腰，使生命穩固，不被虛假與混亂牽引。",
    color: "#74503c",
    symbol: "▰",
    tag: "屬靈軍裝",
    image: "/treasures/belt.png",
    scripture: "以弗所書 6:14",
  },
  {
    id: "gospel-shoes",
    name: "平安福音的鞋",
    subtitle: "SHOES OF THE GOSPEL OF PEACE",
    description: "穿上平安福音的鞋，預備好把和好的消息帶到每個地方。",
    color: "#7a4935",
    symbol: "▱",
    tag: "屬靈軍裝",
    image: "/treasures/shoes.png",
    scripture: "以弗所書 6:15",
  },
  {
    id: "faith-shield",
    name: "信德的籐牌",
    subtitle: "SHIELD OF FAITH",
    description: "舉起信德的籐牌，在試探與攻擊中持續信靠神的信實。",
    color: "#405a78",
    symbol: "◇",
    tag: "屬靈軍裝",
    image: "/treasures/shield.png",
    scripture: "以弗所書 6:16",
  },
  {
    id: "spirit-sword",
    name: "聖靈的寶劍",
    subtitle: "SWORD OF THE SPIRIT",
    description: "拿起聖靈的寶劍，就是神的道，以真理回應每場屬靈爭戰。",
    color: "#526f78",
    symbol: "†",
    tag: "屬靈軍裝",
    image: "/treasures/sword.png",
    scripture: "以弗所書 6:17",
  },
  {
    id: "word-lamp",
    name: "真理的燈",
    subtitle: "LAMP OF THE WORD",
    description: "神的話照亮腳前的路，在迷惘中指引下一步方向。",
    color: "#8f5835",
    symbol: "✦",
    tag: "真理引導",
    image: "/treasures/lamp.png",
    scripture: "詩篇 119:105",
  },
  {
    id: "shepherd-staff",
    name: "牧者的杖",
    subtitle: "THE SHEPHERD'S STAFF",
    description: "象徵著牧者的引導、保護與安慰，使羊群安然前行。",
    color: "#58764d",
    symbol: "⌒",
    tag: "信心道具",
    image: "/treasures/shepherd-staff.png",
    scripture: "詩篇 23:4",
  },
  {
    id: "moses-staff",
    name: "摩西的杖",
    subtitle: "THE STAFF OF MOSES",
    description: "在無路可走之處憑信心舉杖，見證神為百姓開出道路。",
    color: "#416b78",
    symbol: "≋",
    tag: "信心道具",
    image: "/treasures/moses-staff.png",
    scripture: "出埃及記 14:16",
  },
  {
    id: "david-sling",
    name: "大衛的機弦與石子",
    subtitle: "DAVID'S SLING AND STONES",
    description: "看似微小的武器，在信靠神的人手中也能面對巨人。",
    color: "#80523a",
    symbol: "●",
    tag: "信心道具",
    image: "/treasures/sling.png",
    scripture: "撒母耳記上 17:40",
  },
  {
    id: "manna-jar",
    name: "盛嗎哪的金罐",
    subtitle: "THE JAR OF MANNA",
    description: "收藏曠野中的供應，提醒人每天所需都是神所賜。",
    color: "#9a6b32",
    symbol: "◆",
    tag: "神蹟供應",
    image: "/treasures/manna-jar.png",
    scripture: "出埃及記 16:33",
  },
  {
    id: "loaves-and-fish",
    name: "五餅二魚",
    subtitle: "FIVE LOAVES AND TWO FISH",
    description: "把微小所有交給耶穌，就能在祂手中成為眾人的祝福。",
    color: "#8b6a3e",
    symbol: "≋",
    tag: "神蹟供應",
    image: "/treasures/loaves-fish.png",
    scripture: "約翰福音 6:9",
  },
  {
    id: "mustard-seed",
    name: "芥菜種",
    subtitle: "THE MUSTARD SEED",
    description: "即使信心微小如種子，仍能在神裡面生長並帶來改變。",
    color: "#58764d",
    symbol: "•",
    tag: "信心道具",
    image: "/treasures/mustard-seed.png",
    scripture: "馬太福音 17:20",
  },
  {
    id: "elijah-mantle",
    name: "以利亞的外衣",
    subtitle: "THE MANTLE OF ELIJAH",
    description: "落下的外衣象徵使命承接，呼召下一代忠心前行。",
    color: "#9b493a",
    symbol: "▰",
    tag: "使命承接",
    image: "/treasures/elijah-mantle.png",
    scripture: "列王紀下 2:13",
  },
  {
    id: "widow-oil-jar",
    name: "寡婦的油瓶",
    subtitle: "THE WIDOW'S JAR OF OIL",
    description: "僅有的一瓶油因順服而不斷供應，顯明神看顧人的需要。",
    color: "#956237",
    symbol: "◈",
    tag: "神蹟供應",
    image: "/treasures/oil-jar.png",
    scripture: "列王紀下 4:2–7",
  },
  {
    id: "crown-of-life",
    name: "生命的冠冕",
    subtitle: "THE CROWN OF LIFE",
    description: "為忍受試探、持守愛神之人所預備的應許與獎賞。",
    color: "#a97832",
    symbol: "♛",
    tag: "應許獎賞",
    image: "/treasures/crown.png",
    scripture: "雅各書 1:12",
  },
  {
    id: "gideon-torch",
    name: "基甸的火把與瓦瓶",
    subtitle: "GIDEON'S TORCH AND JAR",
    description: "瓦瓶破碎後火光顯露，見證得勝不在人的力量。",
    color: "#8f5637",
    symbol: "✦",
    tag: "使命承接",
    image: "/treasures/gideon-torch.png",
    scripture: "士師記 7:16",
  },
  {
    id: "stone-tablets",
    name: "十誡石版",
    subtitle: "THE TABLETS OF THE COVENANT",
    description: "神親自賜下的約與話語，引導百姓學習聖潔與愛。",
    color: "#776a58",
    symbol: "▥",
    tag: "聖約記號",
    image: "/treasures/tablets.png",
    scripture: "出埃及記 31:18",
  },
  {
    id: "bethlehem-star",
    name: "伯利恆之星",
    subtitle: "THE STAR OF BETHLEHEM",
    description: "照亮夜空的記號，引導遠方博士前往尋見新生王。",
    color: "#9a7030",
    symbol: "★",
    tag: "聖誕珍藏",
    image: "/treasures/bethlehem-star.png",
    scripture: "馬太福音 2:2",
  },
  {
    id: "manger",
    name: "馬槽",
    subtitle: "THE MANGER",
    description: "卑微的餵食槽承接了救主，顯明神以謙卑來到世間。",
    color: "#785238",
    symbol: "▱",
    tag: "聖誕珍藏",
    image: "/treasures/manger.png",
    scripture: "路加福音 2:7",
  },
  {
    id: "gift-of-gold",
    name: "黃金",
    subtitle: "THE GIFT OF GOLD",
    description: "獻給君王的珍貴禮物，表達尊榮與真誠的敬拜。",
    color: "#9a6a2d",
    symbol: "◆",
    tag: "聖誕珍藏",
    image: "/treasures/gold.png",
    scripture: "馬太福音 2:11",
  },
  {
    id: "frankincense",
    name: "乳香",
    subtitle: "THE GIFT OF FRANKINCENSE",
    description: "向上升起的馨香，象徵禱告、敬拜與基督的神性。",
    color: "#8c704d",
    symbol: "≋",
    tag: "聖誕珍藏",
    image: "/treasures/frankincense.png",
    scripture: "馬太福音 2:11",
  },
  {
    id: "myrrh",
    name: "沒藥",
    subtitle: "THE GIFT OF MYRRH",
    description: "珍貴的香料，預告基督將為世人受苦並付上代價。",
    color: "#76503e",
    symbol: "◈",
    tag: "聖誕珍藏",
    image: "/treasures/myrrh.png",
    scripture: "馬太福音 2:11",
  },
]

function PixelStar({ className = "" }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 17 17"
      aria-hidden="true"
      shapeRendering="crispEdges"
    >
      <path
        fill="currentColor"
        d="M7 0h3v5h3v2h4v3h-4v2h-3v5H7v-5H4v-2H0V7h4V5h3V0Z"
      />
      <path fill="#fff5b8" d="M7 5h3v2h2v3h-2v2H7v-2H5V7h2V5Z" />
    </svg>
  )
}

function BlessingJesus({ location }: { location: "entrance" | "home" }) {
  return (
    <div
      className={`blessing-jesus blessing-jesus--${location}`}
      aria-hidden="true"
    >
      <img
        className="blessing-jesus-strip"
        src="/animations/jesus-blessing.webp"
        alt=""
        draggable="false"
      />
    </div>
  )
}

function navigateToCharacter(id: string) {
  window.location.hash = `#/characters/${id}`
}

function PixelCharacterAvatar({ character }: { character: CharacterEntry }) {
  const palettes: Record<string, {
    robe: string
    accent: string
    hair: string
    skin: string
  }> = {
    mary: {
      robe: "#456f93",
      accent: "#d7e3e8",
      hair: "#52362b",
      skin: "#d9a477",
    },
    joseph: {
      robe: "#895936",
      accent: "#d3a65f",
      hair: "#493229",
      skin: "#bf855e",
    },
    shepherds: {
      robe: "#68784b",
      accent: "#ded0a7",
      hair: "#5a4333",
      skin: "#c99167",
    },
    magi: {
      robe: "#634b84",
      accent: "#e2b94f",
      hair: "#302923",
      skin: "#a96f4f",
    },
  }
  const palette = palettes[character.id] ?? palettes.mary

  return (
    <svg
      className="pixel-character-avatar"
      viewBox="0 0 96 112"
      role="img"
      aria-label={`${character.name}像素角色圖`}
      shapeRendering="crispEdges"
    >
      <rect x="24" y="16" width="48" height="44" fill={palette.hair} />
      {character.id === "mary" && (
        <path fill={palette.robe} d="M16 16h64v56H68V28H28v44H16V16Z" />
      )}
      {character.id === "magi" && (
        <path fill={palette.accent} d="M24 4h10v8h10V4h10v8h10V4h10v16H24V4Z" />
      )}
      <rect x="29" y="25" width="38" height="38" fill={palette.skin} />
      <rect x="34" y="39" width="7" height="7" fill="#17262d" />
      <rect x="55" y="39" width="7" height="7" fill="#17262d" />
      <rect x="42" y="53" width="13" height="4" fill="#8f5148" />
      {character.id !== "mary" && (
        <path fill={palette.hair} d="M28 55h8v9h24v-9h8v18H28V55Z" />
      )}
      <path fill={palette.robe} d="M20 72h56v8h8v32H12V80h8v-8Z" />
      <rect x="39" y="72" width="18" height="40" fill={palette.accent} />
      {character.id === "shepherds" && (
        <path
          fill="#6a4429"
          d="M82 31h8v81h-8V31Zm-12-12h12v8H70v-8Zm-8 8h8v8h-8v-8Z"
        />
      )}
      {character.id === "magi" && (
        <rect x="66" y="84" width="22" height="20" fill={palette.accent} />
      )}
    </svg>
  )
}

function PixelScene({ compact = false }: { compact?: boolean }) {
  return (
    <div
      className={`pixel-scene ${compact ? "pixel-scene--compact" : ""}`}
      aria-hidden="true"
    >
      <div className="moon" />
      <PixelStar className="scene-star scene-star--one" />
      <PixelStar className="scene-star scene-star--two" />
      <PixelStar className="scene-star scene-star--three" />
      <div className="snow snow--back" />
      <div className="mountain mountain--left" />
      <div className="mountain mountain--right" />
      <div className="village">
        <div className="pixel-tree pixel-tree--one">
          <i />
          <i />
          <i />
        </div>
        <div className="pixel-house pixel-house--one">
          <i />
        </div>
        <div className="pixel-tree pixel-tree--two">
          <i />
          <i />
          <i />
        </div>
        <div className="pixel-house pixel-house--two">
          <i />
        </div>
        <div className="pixel-tree pixel-tree--three">
          <i />
          <i />
          <i />
        </div>
      </div>
      <div className="snow snow--front" />
    </div>
  )
}

function StartScreen({ onEnter }: { onEnter: () => void }) {
  return (
    <button
      className="start-screen"
      onClick={onEnter}
      type="button"
      aria-label="進入 Christmas Quest"
    >
      <PixelScene />
      <BlessingJesus location="entrance" />
      <div className="start-vignette" />
      <div className="start-content">
        <div className="pixel-badge">A BIBLE STORY ADVENTURE</div>
        <h1>
          <span>CHRISTMAS</span>
          <span>QUEST</span>
        </h1>
        <p className="start-subtitle">跟隨星光，遇見聖誕故事裡的每一個人</p>
      </div>
      <div className="press-start">
        <span className="cursor-block" />
        點擊任意位置，開始冒險
      </div>
    </button>
  )
}

function Navigation({ page, goTo }: NavigationProps) {
  return (
    <header className="topbar">
      <button className="brand" onClick={() => goTo("home")} type="button">
        <PixelStar />
        <span>CQ</span>
      </button>
      <nav aria-label="主要選單">
        <button
          className={page === "home" ? "active" : ""}
          onClick={() => goTo("home")}
          type="button"
        >
          首頁
        </button>
        <button
          className={
            page === "characters" || page === "character-detail" ? "active" : ""
          }
          onClick={() => goTo("characters")}
          type="button"
        >
          人物圖鑑
        </button>
        <button
          className={page === "treasures" ? "active" : ""}
          onClick={() => goTo("treasures")}
          type="button"
        >
          寶物圖鑑
        </button>
        <button
          className={page === "game" ? "active" : ""}
          onClick={() => goTo("game")}
          type="button"
        >
          遊戲
        </button>
      </nav>
    </header>
  )
}

function Footer({ goTo }: { goTo: (page: Page) => void }) {
  const scrollToHomeSection = (sectionId: string) => {
    goTo("home")
    window.setTimeout(
      () =>
        document
          .getElementById(sectionId)
          ?.scrollIntoView({ behavior: "smooth" }),
      50,
    )
  }

  return (
    <footer id="church-info" className="site-footer">
      <div className="footer-star">
        <PixelStar />
      </div>
      <div className="footer-main">
        <div className="footer-church">
          <p className="footer-kicker">STAR OF ARTISTS CHURCH</p>
          <h2>藝之星教會</h2>
          <p>歡迎青少年、社青、成人、家庭與親子朋友加入我們。</p>
          <a
            className="footer-address"
            href="https://www.google.com/maps/search/?api=1&query=台北市南港區八德路四段869號B1"
            target="_blank"
            rel="noreferrer"
          >
            台北市南港區八德路四段 869 號 B1
          </a>
          <div className="footer-contact">
            <a href="tel:+886226516317">02 2651 6317</a>
            <a href="mailto:starofartists@gmail.com">starofartists@gmail.com</a>
          </div>
        </div>
        <div className="footer-info">
          <div>
            <span>烈火禱告會</span>
            <strong>每月第一、第三個週二 19:30</strong>
          </div>
          <div>
            <span>週六主日聚會</span>
            <strong>每週六 17:00</strong>
            <small>歡迎青少年及社青朋友</small>
          </div>
          <div>
            <span>週日主日聚會</span>
            <strong>第一堂 09:00 · 第二堂 11:00</strong>
            <small>歡迎成人、家庭及親子朋友</small>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© 2025 藝之星教會 · CHRISTMAS QUEST</p>
        <div>
          <a
            href="#/"
            onClick={(event) => {
              event.preventDefault()
              scrollToHomeSection("about")
            }}
          >
            關於我們
          </a>
          <a
            href="#/"
            onClick={(event) => {
              event.preventDefault()
              scrollToHomeSection("guide")
            }}
          >
            新朋友指引
          </a>
          <a href="tel:+886226516317">聯絡教會</a>
          <a
            href="https://www.facebook.com/Christianartists/"
            target="_blank"
            rel="noreferrer"
          >
            Facebook
          </a>
        </div>
      </div>
    </footer>
  )
}

function HomePage({ goTo }: { goTo: (page: Page) => void }) {
  return (
    <>
      <main>
        <section className="hero" id="about">
          <PixelScene compact />
          <BlessingJesus location="home" />
          <div className="hero-content">
            <p className="eyebrow">CHAPTER 01 · THE STORY BEGINS</p>
            <h1>
              CHRISTMAS
              <br />
              <span>QUEST</span>
            </h1>
            <p className="hero-lead">一場穿越伯利恆星夜的像素冒險</p>
            <div className="scroll-cue">
              <span />
              向下探索
            </div>
          </div>
        </section>

        <section className="intro-section">
          <div className="section-number">01</div>
          <div className="intro-copy">
            <p className="eyebrow dark">WELCOME, TRAVELER</p>
            <h2>
              故事不只發生在
              <br />
              兩千年前。
            </h2>
          </div>
          <div className="intro-detail">
            <p>
              每一位人物，都帶著一段選擇與回應；每一件寶物，都藏著聖誕故事的線索。
            </p>
            <p>翻開圖鑑，認識他們的旅程。也許你會在故事裡，找到今天的自己。</p>
          </div>
        </section>

        <section className="guide-section" id="guide">
          <div className="guide-heading">
            <p className="eyebrow">PLAYER GUIDE</p>
            <h2>冒險指引</h2>
            <p>選擇你的探索路線，蒐集故事碎片，完成這趟聖誕旅程。</p>
          </div>
          <button
            className="game-entry-button"
            onClick={() => goTo("game")}
            type="button"
          >
            <span>
              <small>NEW ADVENTURE</small>
              <strong>開始遊戲</strong>
            </span>
            <b>信心不掉線，恩典無極限!! →</b>
          </button>
        </section>

        <section className="choose-section">
          <p className="eyebrow dark">CHOOSE YOUR PATH</p>
          <h2>你想先探索哪一本圖鑑？</h2>
          <div className="steps">
            <div className="step">
              <b>01</b>
              <span>SELECT</span>
              <h3>選擇圖鑑</h3>
              <p>從人物或寶物開始探索</p>
            </div>
            <div className="step-line" />
            <div className="step">
              <b>02</b>
              <span>DISCOVER</span>
              <h3>閱讀故事</h3>
              <p>發現每個角色背後的信心</p>
            </div>
            <div className="step-line" />
            <div className="step">
              <b>03</b>
              <span>REFLECT</span>
              <h3>帶走亮光</h3>
              <p>讓古老故事照亮今天</p>
            </div>
          </div>
          <div className="path-grid">
            <button
              className="path-card path-card--people"
              onClick={() => goTo("characters")}
              type="button"
            >
              <div className="card-index">01</div>
              <div className="path-card-title">
                <span className="card-label">CHARACTER ARCHIVE</span>
                <h3>人物圖鑑</h3>
              </div>
              <div className="card-art" aria-hidden="true">
                <img
                  className="card-art-image"
                  src="/illustrations/character-archive.webp"
                  alt=""
                />
              </div>
              <span className="card-arrow">
                進入圖鑑 <b>→</b>
              </span>
            </button>
            <button
              className="path-card path-card--treasure"
              onClick={() => goTo("treasures")}
              type="button"
            >
              <div className="card-index">02</div>
              <div className="path-card-title">
                <span className="card-label">TREASURE ARCHIVE</span>
                <h3>寶物圖鑑</h3>
              </div>
              <div className="card-art" aria-hidden="true">
                <img
                  className="card-art-image"
                  src="/illustrations/treasure-archive.webp"
                  alt=""
                />
              </div>
              <span className="card-arrow">
                進入圖鑑 <b>→</b>
              </span>
            </button>
          </div>
          <section className="social-links-section" aria-labelledby="social-links-title">
            <div className="social-links-heading">
              <p className="eyebrow dark">STAY CONNECTED</p>
              <h2 id="social-links-title">與藝之星保持連線</h2>
            </div>
            <div className="social-links-grid">
              <a
                className="social-link social-link--facebook"
                href="https://www.facebook.com/Christianartists"
                target="_blank"
                rel="noreferrer"
              >
                <span className="social-link-icon" aria-hidden="true">
                  <svg viewBox="0 0 32 32">
                    <path d="M19.1 32V17.4h4.8l.8-5.7h-5.6V8.1c0-1.7.5-2.8 2.9-2.8h3V.2C24.5.1 22.7 0 20.6 0c-4.2 0-7 2.5-7 7.2v4.5H9v5.7h4.6V32h5.5Z" />
                  </svg>
                </span>
                <span className="social-link-copy">
                  <small>FOLLOW ON FACEBOOK</small>
                  <strong>藝之星教會 FB</strong>
                </span>
                <b aria-hidden="true">↗</b>
              </a>
              <a
                className="social-link social-link--instagram"
                href="https://www.instagram.com/starofartists869/"
                target="_blank"
                rel="noreferrer"
              >
                <span className="social-link-icon" aria-hidden="true">
                  <svg viewBox="0 0 32 32">
                    <rect x="4" y="4" width="24" height="24" rx="7" />
                    <circle cx="16" cy="16" r="5.5" />
                    <circle className="social-icon-dot" cx="23.5" cy="8.7" r="1.5" />
                  </svg>
                </span>
                <span className="social-link-copy">
                  <small>FOLLOW ON INSTAGRAM</small>
                  <strong>藝之星教會 IG</strong>
                </span>
                <b aria-hidden="true">↗</b>
              </a>
              <a
                className="social-link social-link--youtube"
                href="https://www.youtube.com/@starofartists224"
                target="_blank"
                rel="noreferrer"
              >
                <span className="social-link-icon" aria-hidden="true">
                  <svg viewBox="0 0 32 32">
                    <rect x="2" y="6" width="28" height="20" rx="6" />
                    <path d="m13 11 9 5-9 5Z" />
                  </svg>
                </span>
                <span className="social-link-copy">
                  <small>SUBSCRIBE ON YOUTUBE</small>
                  <strong>訂閱藝之星 YT</strong>
                </span>
                <b aria-hidden="true">↗</b>
              </a>
            </div>
          </section>
        </section>
      </main>
      <Footer goTo={goTo} />
    </>
  )
}

function GamePage() {
  return (
    <button
      className="game-start-screen"
      onClick={() =>
        window.location.assign("https://www.astrocade.com/s/fJcXVTOUc2")
      }
      type="button"
      aria-label="點擊任意位置進入 Christmas Quest 遊戲"
    >
      <div className="game-start-map" aria-hidden="true" />
      <div className="game-start-shade" aria-hidden="true" />
      <div className="game-start-lights" aria-hidden="true">
        <i />
        <i />
        <i />
        <i />
        <i />
      </div>
      <div className="game-start-snow game-start-snow--far" aria-hidden="true" />
      <div className="game-start-snow game-start-snow--near" aria-hidden="true" />
      <div className="game-start-frame" aria-hidden="true" />
      <div className="game-start-content">
        <div className="game-title-lockup">
          <span className="pixel-badge">CHRISTMAS QUEST · GAME GUIDE</span>
          <h1>
            雪地冒險
            <strong>準備開始</strong>
          </h1>
          <p>尋找地圖上的所有光點，擊敗大BOSS吧!</p>
        </div>
      </div>
      <div className="game-press-start">
        <span className="cursor-block" />
        點擊任意位置，進入遊戲
      </div>
    </button>
  )
}

function CatalogPage({
  kind,
  goTo,
}: {
  kind: "characters" | "treasures"
  goTo: (page: Page) => void
}) {
  const isCharacters = kind === "characters"
  const entries = isCharacters ? characters : treasures
  const treasureGroups = [
    {
      eyebrow: "ARMOR OF GOD",
      title: "屬靈軍裝",
      description: "穿戴神所賜的全副軍裝，在每一天的屬靈爭戰中站立得穩。",
      tags: ["屬靈軍裝"],
    },
    {
      eyebrow: "FAITH JOURNEY",
      title: "信心旅程",
      description: "在呼召、選擇與堅持中，陪伴旅人前行的信心記號。",
      tags: ["真理引導", "信心道具", "使命承接", "應許獎賞", "聖約記號"],
    },
    {
      eyebrow: "MIRACLES & PROVISION",
      title: "神蹟與供應",
      description: "記念神在缺乏與困境中，仍然豐盛供應並開出道路。",
      tags: ["神蹟供應"],
    },
    {
      eyebrow: "CHRISTMAS COLLECTION",
      title: "聖誕珍藏",
      description: "收藏耶穌降生故事中的記號與遠方博士所獻上的禮物。",
      tags: ["聖誕珍藏"],
    },
  ].map((group) => ({
    ...group,
    entries: treasures.filter((entry) => group.tags.includes(entry.tag)),
  }))

  const renderCatalogEntry = (entry: CatalogEntry, index: number) => {
    const cardContent = (
      <>
        <div
          className="catalog-art"
          style={{ "--entry-color": entry.color } as React.CSSProperties}
        >
          {isCharacters ? (
            <img
              src={(entry as CharacterEntry).image}
              alt={`${entry.name}角色圖卡`}
            />
          ) : entry.image ? (
            <img
              className="treasure-art-image"
              src={entry.image}
              alt={`${entry.name}像素圖示`}
            />
          ) : (
            <span>{entry.symbol}</span>
          )}
          <i>NO.{String(index + 1).padStart(3, "0")}</i>
        </div>
        <div className="catalog-card-copy">
          <div className="catalog-meta">
            <span>{entry.subtitle}</span>
            <b>{entry.tag}</b>
          </div>
          <h2>{entry.name}</h2>
          <p>{entry.description}</p>
          {isCharacters && (
            <span className="catalog-open">查看人物故事 →</span>
          )}
          {!isCharacters && entry.scripture && (
            <span className="treasure-source">
              聖經出處｜{entry.scripture}
            </span>
          )}
        </div>
      </>
    )

    return isCharacters ? (
      <button
        className="catalog-card catalog-card--interactive"
        key={entry.id}
        onClick={() => navigateToCharacter(entry.id)}
        type="button"
      >
        {cardContent}
      </button>
    ) : (
      <article className="catalog-card" key={entry.id}>
        {cardContent}
      </article>
    )
  }

  const lockedCard = (
    <article className="catalog-card catalog-card--locked">
      <div className="locked-symbol">?</div>
      <div>
        <span>NEXT UPDATE</span>
        <h2>{isCharacters ? "新的故事即將解鎖" : "新的寶物即將解鎖"}</h2>
        <p>
          {isCharacters
            ? "圖鑑已預留擴充空間，敬請期待下一位旅人。"
            : "圖鑑已預留擴充空間，敬請期待下一件收藏。"}
        </p>
      </div>
    </article>
  )

  return (
    <>
      <main className="catalog-page">
        <section
          className={`catalog-hero ${
            isCharacters ? "" : "catalog-hero--treasures"
          }`}
        >
          <div className="catalog-stars">
            <PixelStar />
            <PixelStar />
            <PixelStar />
          </div>
          <p className="eyebrow">
            {isCharacters ? "CHARACTER ARCHIVE" : "TREASURE ARCHIVE"}
          </p>
          <h1>{isCharacters ? "人物圖鑑" : "寶物圖鑑"}</h1>
          <p>
            {isCharacters
              ? "記錄每一位聖經人物的選擇、信心與旅程。"
              : "蒐集故事中的重要物件，解開它們承載的意義。"}
          </p>
          <div className="archive-count">
            ARCHIVE <b>{String(entries.length).padStart(2, "0")}</b>
          </div>
        </section>
        <section className="catalog-content">
          <div className="catalog-toolbar">
            <button onClick={() => goTo("home")} type="button">
              ← 返回任務大廳
            </button>
            <span>已解鎖 {entries.length} / 持續新增中</span>
          </div>
          {isCharacters ? (
            <div className="catalog-grid">
              {characters.map(renderCatalogEntry)}
              {lockedCard}
            </div>
          ) : (
            <div className="treasure-sections">
              {treasureGroups.map((group) => (
                <section className="treasure-group" key={group.title}>
                  <header className="treasure-group-heading">
                    <div>
                      <span>{group.eyebrow}</span>
                      <h2>{group.title}</h2>
                      <p>{group.description}</p>
                    </div>
                    <b>{String(group.entries.length).padStart(2, "0")} 件</b>
                  </header>
                  <div className="catalog-grid catalog-grid--treasures">
                    {group.entries.map((entry) =>
                      renderCatalogEntry(entry, treasures.indexOf(entry)),
                    )}
                  </div>
                </section>
              ))}
              <div className="catalog-grid catalog-grid--treasures treasure-coming">
                {lockedCard}
              </div>
            </div>
          )}
        </section>
      </main>
      <Footer goTo={goTo} />
    </>
  )
}

function CharacterDetailPage({
  character,
  goTo,
}: {
  character: CharacterEntry
  goTo: (page: Page) => void
}) {
  const currentIndex = characters.findIndex((item) => item.id === character.id)
  const safeIndex = currentIndex >= 0 ? currentIndex : 0
  const previousCharacter =
    characters[(safeIndex - 1 + characters.length) % characters.length]
  const nextCharacter = characters[(safeIndex + 1) % characters.length]
  const traits =
    Array.isArray(character.traits) && character.traits.length > 0
      ? character.traits
      : [character.tag]
  const story =
    Array.isArray(character.story) && character.story.length > 0
      ? character.story
      : [character.description]
  const verse = character.verse || "經文資料整理中"
  const quote = character.quote || character.description
  const famousEvent = character.famousEvent || character.description
  const books =
    character.books || `聖經未記載${character.name}撰寫任何書卷`

  return (
    <>
      <main className="character-detail">
        <section
          className="character-detail-hero"
          style={
            { "--character-color": character.color } as React.CSSProperties
          }
        >
          <div className="detail-pixels" aria-hidden="true" />
          <button
            className="detail-back"
            onClick={() => goTo("characters")}
            type="button"
          >
            ← 返回人物圖鑑
          </button>
          <div className="character-portrait">
            <div className="portrait-card">
              <div className="portrait-card-art">
                <img src={character.image} alt={`${character.name}角色圖卡`} />
              </div>
              <div className="portrait-card-name">
                <span>
                  NO.{String(safeIndex + 1).padStart(3, "0")} ·{" "}
                  {character.subtitle}
                </span>
                <strong>{character.name}</strong>
              </div>
            </div>
          </div>
          <div className="character-heading">
            <p className="eyebrow">{character.subtitle}</p>
            <h1>{character.name}</h1>
            <div className="trait-list">
              {traits.map((trait) => (
                <span key={trait}>{trait}</span>
              ))}
            </div>
          </div>
        </section>

        <section className="character-story">
          <aside>
            <div className="detail-fact">
              <p className="detail-label">REPRESENTATIVE VERSE</p>
              <strong>{verse}</strong>
            </div>
            <div className="detail-divider" />
            <div className="detail-fact">
              <p className="detail-label">KEYWORD</p>
              <strong>{character.tag}</strong>
            </div>
            <div className="detail-divider" />
            <div className="detail-fact">
              <p className="detail-label">BIBLICAL BOOKS</p>
              <strong>{books}</strong>
            </div>
          </aside>
          <article>
            <p className="eyebrow dark">FAMOUS STORY & MIRACLES</p>
            <h2>{famousEvent}</h2>
            {story.map((paragraph) => (
              <p key={paragraph}>{paragraph}</p>
            ))}
          </article>
        </section>

        <section className="character-quote">
          <PixelStar />
          <blockquote>「{quote}」</blockquote>
          <span>{verse} · 中文和合本</span>
        </section>

        <section className="detail-next">
          <a
            className="detail-previous"
            href={`#/characters/${previousCharacter.id}`}
          >
            <b>←</b>
            <span>上一位</span>
            <strong>{previousCharacter.name}</strong>
          </a>
          <div className="detail-next-heading">
            <p className="eyebrow dark">CONTINUE YOUR QUEST</p>
            <h2>繼續認識其他人物</h2>
          </div>
          <a
            className="detail-forward"
            href={`#/characters/${nextCharacter.id}`}
          >
            <span>下一位</span>
            <strong>{nextCharacter.name}</strong>
            <b>→</b>
          </a>
        </section>
      </main>
      <Footer goTo={goTo} />
    </>
  )
}

function pageFromHash(): Page {
  const hash = window.location.hash.replace("#/", "")
  if (hash.startsWith("characters/")) {
    const id = hash.split("/")[1]
    return characters.some((character) => character.id === id)
      ? "character-detail"
      : "characters"
  }
  return hash === "characters" || hash === "treasures" || hash === "game"
    ? hash
    : "home"
}

function characterFromHash(hash = window.location.hash) {
  const id = hash.replace("#/characters/", "")
  return characters.find((character) => character.id === id)
}

export default function App() {
  const [entered, setEntered] = useState(false)
  const [page, setPage] = useState<Page>(pageFromHash)
  const [currentHash, setCurrentHash] = useState(window.location.hash)

  useEffect(() => {
    const onHashChange = () => {
      setCurrentHash(window.location.hash)
      setPage(pageFromHash())
      setEntered(true)
      window.scrollTo({ top: 0, behavior: "smooth" })
    }
    window.addEventListener("hashchange", onHashChange)
    return () => window.removeEventListener("hashchange", onHashChange)
  }, [])

  const goTo = (nextPage: Page) => {
    const safePage = nextPage === "character-detail" ? "characters" : nextPage
    const hash = safePage === "home" ? "#/" : `#/${safePage}`
    if (window.location.hash === hash) {
      setPage(nextPage)
      window.scrollTo({ top: 0, behavior: "smooth" })
    } else {
      window.location.hash = hash
    }
  }

  if (!entered && window.location.hash === "") {
    return (
      <StartScreen
        onEnter={() => {
          setEntered(true)
          window.location.hash = "#/"
        }}
      />
    )
  }

  const detailCharacter =
    page === "character-detail" ? characterFromHash(currentHash) : undefined

  return (
    <div className="app-shell">
      <Navigation page={page} goTo={goTo} />
      {page === "home" && <HomePage goTo={goTo} />}
      {page === "game" && <GamePage />}
      {detailCharacter && (
        <CharacterDetailPage character={detailCharacter} goTo={goTo} />
      )}
      {(page === "characters" || page === "treasures") && (
        <CatalogPage kind={page} goTo={goTo} />
      )}
    </div>
  )
}
